G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-11-08T17:45:35+01:00*
G04 #@! TF.ProjectId,USB_to_Fiber_converter,5553425f-746f-45f4-9669-6265725f636f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-11-08 17:45:35*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.300000X1.300000*%
%ADD11C,1.300000*%
%ADD12C,1.650000*%
%ADD13O,2.900000X1.200000*%
%ADD14RoundRect,0.325000X-1.175000X0.325000X-1.175000X-0.325000X1.175000X-0.325000X1.175000X0.325000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,IC1*
X185540000Y-107440000D03*
D11*
X185540000Y-104900000D03*
X185540000Y-102360000D03*
D12*
X188160000Y-107440000D03*
X188160000Y-102360000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X177500000Y-106400000D03*
X177500000Y-93600000D03*
D14*
X181200000Y-103500000D03*
X181200000Y-101000000D03*
X181200000Y-99000000D03*
X181200000Y-96500000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,U3*
X185440000Y-97500000D03*
D11*
X185440000Y-94960000D03*
X185440000Y-92420000D03*
D12*
X188060000Y-97500000D03*
X188060000Y-92420000D03*
G04 #@! TD*
M02*
